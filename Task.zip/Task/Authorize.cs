﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Collections;
using Newtonsoft.Json.Linq;

namespace Task
{
    public class BasicHttpAuthorizeAttribute : System.Web.Http.AuthorizeAttribute
    {
        private clsdb objDB = new clsdb();
        /// <summary>
        /// API for User Authorization
        /// </summary>
        /// <param name="actionContext"></param>
        /// <modified_by>Ranjita</modified_by>
        /// <modified_on>14-08-2020</modified_on>
        public override void OnAuthorization(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            string token;
            var dataArray = new JArray();
            if (actionContext.Request.Headers.Contains("token"))
            {
                token = actionContext.Request.Headers.GetValues("token").First();
                if (token != "")
                {
                    dataArray = objDB.RunSQL("SELECT * FROM tbl_login WHERE token='" + token + "'");

                    if (dataArray.Count == 0)
                    {
                        actionContext.Response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.Unauthorized);
                    }
                    else
                    {
                        HttpContext.Current.Items["userId"] = dataArray[0]["userId"].ToString();
                    }
                }
                else
                {
                    actionContext.Response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.Forbidden);
                }
            }
            else
            {
                actionContext.Response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.Forbidden);
            }
        }


    }
}