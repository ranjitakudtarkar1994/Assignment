﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Task.Models
{
    public class postData
    {
        public int userId { get; set; }
        public string userName { get; set; }
        public string date { get; set; }
        public string title { get; set; }
        public string description { get; set; }
    }
    interface IBlogPostData
    {
        IEnumerable<postData> GetAll();
        postData Login(int id);
        postData GetAllPost(int id);
    }

    public class PostRepository : IBlogPostData
    {
        private List<postData> data = new List<postData>
        {
            new postData { userId = 1, userName = "User 1", date = "2020-08-01", title = "Travel" , description = "Travel" },
            new postData { userId = 2, userName = "User 2", date = "2020-08-02", title = "Health" , description = "Health" },
            new postData { userId = 3, userName = "User 3", date = "2020-08-03", title = "Finance" , description = "Finance" },
            new postData { userId = 4, userName = "User 4", date = "2020-08-04", title = "Entertainment" , description = "Entertainment" }
        };

        public IEnumerable<postData> GetAll()
        {
            return data;
        }

        public postData Login(int id)
        {
            return data.Find(x => x.userId == id);
        }
        public postData GetAllPost(int id)
        {
            return data.Find(x => x.userId == id);
        }
    }

}