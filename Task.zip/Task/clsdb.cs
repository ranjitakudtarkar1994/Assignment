﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

namespace Task
{
    public class clsdb
    {
        //Get connection string and open connection
        protected MySqlConnection GetConnection()
        {
          
            MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);

            conn.Open();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conn;
            cmd.ExecuteNonQuery();    
            return conn;
        }

        //Close the connection
        protected void CloseConnection(MySqlConnection conn)
        {
            conn.Close();
        }
        public JArray RunSQL(string strSQL)
        {

            MySqlConnection cn = GetConnection();
            MySqlDataReader rdr = default(MySqlDataReader);
            MySqlCommand cmd = new MySqlCommand(strSQL, cn);
            var jsonData = new JArray();
            try
            {
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                var data = new DataTable();

                DataSet ds = new DataSet();
                da.Fill(ds);

                data = ds.Tables[0];

                string JSONString = string.Empty;
                JSONString = JsonConvert.SerializeObject(data);
                jsonData = JArray.Parse(JSONString);

            }

            finally
            {
                CloseConnection(cn);
            }
            return jsonData;

        }
        //Execute Action Query (Insert/Delete)
        public void RunActionQuery(string strSQL)
        {
            MySqlConnection cn = GetConnection();
            MySqlCommand cmd = new MySqlCommand(strSQL, cn);


            try
            {
                cmd.ExecuteNonQuery();
            }
            finally
            {

                CloseConnection(cn);
            }

        }

    }
}