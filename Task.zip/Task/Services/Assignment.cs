﻿using Microsoft.Ajax.Utilities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Task.Models;

namespace Task.Services
{
    public class Assignment
    {
        private ResultModel result = new ResultModel();
        private clsdb objDB = new clsdb();
        public ResultModel Login(int userId)
        {
            StringBuilder tokenString = new StringBuilder();
            string strTms = "";
            string strToken = "";
            string str = "";
            JArray arrData = new JArray();
            try
            {
                if (userId != 0)
                {
                    str += "SELECT user_id FROM tbl_login WHERE user_id = '"+userId+"'";
                    arrData = objDB.RunSQL(str);
                    if (arrData.Count == 1)
                    {
                        string s = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                        Random r = new Random();
                        for (int i = 0; i < 15; i++)
                        {
                            int idx = r.Next(0, 35);
                            tokenString.Append(s.Substring(idx, 1));
                        }
                        tokenString.Append(tokenString.ToString() + strTms.ToString());
                        byte[] byt = System.Text.Encoding.UTF8.GetBytes(tokenString.ToString());
                        strToken = System.Convert.ToBase64String(byt);
                        arrData[0]["token"] = strToken;
                        objDB.RunActionQuery("UPDATE tbl_login  SET token='" + strToken + "' WHERE  user_id = " + userId + " ");

                        result.Status = "Success";
                        result.Code = 1;
                        result.Msg = "Login Successful..";
                        result.Data = arrData;
                    }
                    else
                    {
                        result.Status = "Error";
                        result.Code = -1;
                        result.Msg = "Data Not Found..!!";
                        result.Data = arrData;
                    }
                }
                else
                {
                    result.Status = "Error";
                    result.Code = -1;
                    result.Msg = "Invalid User..!!";
                    result.Data = arrData;
                }

            }
            catch (Exception ex)
            {
                result.Status = "Error";
                result.Code = -1;
                result.Msg = ex.Message.ToString();
                result.Data = arrData;
            }
            return result;
        }

        public ResultModel GetAllPost(int userId)
        {
            string str = "";
            JArray arrData = new JArray();
            try
            {
                if (userId != 0)
                {
                    str += "SELECT * FROM tbl_bgPost WHERE user_id = '" + userId + "'";
                    arrData = objDB.RunSQL(str);
                    if (arrData.Count > 0)
                    {
                        result.Status = "Success";
                        result.Code = 1;
                        result.Msg = "Success";
                        result.Data = arrData;
                    }
                    else
                    {
                        result.Status = "Error";
                        result.Code = -1;
                        result.Msg = "Data Not Found..!!";
                        result.Data = arrData;
                    }
                }
                else
                {
                    result.Status = "Error";
                    result.Code = -1;
                    result.Msg = "Invalid User..!!";
                    result.Data = arrData;
                }

            }
            catch (Exception ex)
            {
                result.Status = "Error";
                result.Code = -1;
                result.Msg = ex.Message.ToString();
                result.Data = arrData;
            }
            return result;
        }
    }
}