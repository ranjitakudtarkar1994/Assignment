﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Task.Models;
using Task.Models;

namespace Task.Controllers
{
    
    public class ValuesController : ApiController
    {
        private IBlogPostData bgPostData = new PostRepository();
        // GET api/values
        public IEnumerable<postData> Get()
        {
            return bgPostData.GetAll();
        }

        public postData Login(int id)
        {
            return bgPostData.Login(id);

        }
        // GET api/values/5
        public postData Get(int id)
        {
            return bgPostData.GetAllPost(id);
        }

       
    }
}
