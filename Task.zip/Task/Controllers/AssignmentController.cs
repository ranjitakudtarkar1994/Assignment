﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Task.Models;
using Task.Services;

namespace Task.Controllers
{
    public class AssignmentController : ApiController
    {
        private Assignment setLogin = new Assignment();
        [HttpGet]
        public ResultModel Login(int userId)
        {
            return setLogin.Login(userId);
        }

        [BasicHttpAuthorizeAttribute]
        [HttpGet]
        public ResultModel Get(int userId)
        {
            return setLogin.GetAllPost(userId);
        }

    }
}
